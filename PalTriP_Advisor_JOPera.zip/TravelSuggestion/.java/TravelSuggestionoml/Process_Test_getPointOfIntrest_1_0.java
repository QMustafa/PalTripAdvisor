//JOpera Process Template Plugin
//OML2Java Compiler Version 1.12 $Revision: 6795 $
package TravelSuggestionoml;import org.jopera.kernel.*;import org.jopera.kernel.api.APIConsts;import java.util.*;import java.io.Serializable;public class Process_Test_getPointOfIntrest_1_0 extends Template {public String getOMLPath() {  return "\\TravelSuggestion\\TravelSuggestionoml.oml";}

public String getOML() {  return "<PROCS><PROC OID=\"Process650\" NAME=\"Test_getPointOfIntrest\" DESC=\"Automatically generated test process for getPointOfIntrest\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter655\" NAME=\"country\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter656\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity657\" NAME=\"getPointOfIntrest\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program17\" /></TASKS><DATAFLOW><BIND OID=\"Binding663\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter655\" DESTPID=\"InboxParameter18\" DESTTID=\"Activity657\" ACTION=\"0\" /><BIND OID=\"Binding669\" SRCTYP=\"1\" DESTTYP=\"3\" SRCPID=\"OutboxParameter417\" DESTPID=\"OutboxParameter656\" SRCTID=\"Activity657\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View651\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox659\" X=\"0.0\" Y=\"50.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity657\" REFTYPE=\"0\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View652\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow664\" SOURCE=\"RefBox662\" DESTINATION=\"RefBox660\" REF=\"Binding663\" REFTYPE=\"1\" ROUTE=\"2\" /><ARROW OID=\"Arrow670\" SOURCE=\"RefBox668\" DESTINATION=\"RefBox665\" REF=\"Binding669\" REFTYPE=\"1\" ROUTE=\"2\" /></ARROWS><BOXES><RBOX OID=\"RefBox653\" X=\"129.0\" Y=\"143.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process650\" REFTYPE=\"5\"><BOXES><RBOX OID=\"RefBox662\" X=\"181.0\" Y=\"191.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter655\" REFTYPE=\"3\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox654\" X=\"184.0\" Y=\"438.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process650\" REFTYPE=\"6\"><BOXES><RBOX OID=\"RefBox665\" X=\"213.0\" Y=\"383.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter656\" REFTYPE=\"4\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox658\" X=\"171.0\" Y=\"279.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity657\" REFTYPE=\"0\"><BOXES><RBOX OID=\"RefBox660\" X=\"187.0\" Y=\"237.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter18\" REFTYPE=\"3\"><BOXES /></RBOX><RBOX OID=\"RefBox668\" X=\"203.0\" Y=\"337.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter417\" REFTYPE=\"9\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program17\" NAME=\"getPointOfIntrest\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter18\" NAME=\"country\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter132\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getOMLInterface() {  return "<PROCINTER><INBOX><PARAM OID=\"InboxParameter655\" NAME=\"country\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter656\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></OUTBOX></PROCINTER>";}

public String getOML1() {  return "<PROCS><PROC OID=\"Process650\" NAME=\"Test_getPointOfIntrest\" DESC=\"Automatically generated test process for getPointOfIntrest\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter655\" NAME=\"country\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter656\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity657\" NAME=\"getPointOfIntrest\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program17\" /></TASKS><DATAFLOW><BIND OID=\"Binding663\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter655\" DESTPID=\"InboxParameter18\" DESTTID=\"Activity657\" ACTION=\"0\" /><BIND OID=\"Binding669\" SRCTYP=\"1\" DESTTYP=\"3\" SRCPID=\"OutboxParameter417\" DESTPID=\"OutboxParameter656\" SRCTID=\"Activity657\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View651\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox659\" DX=\"0.0\" DY=\"0.0\" X=\"0.0\" Y=\"-1.6666666\" REF=\"Activity657\" TYPE=\"0\" REFNAME=\"getPointOfIntrest\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View652\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow664\" REF=\"Binding663\" ROUTE=\"2\" ID1=\"RefBox662\" ID2=\"RefBox660\" TYPE=\"0\" /><ARROW OID=\"Arrow670\" REF=\"Binding669\" ROUTE=\"2\" ID1=\"RefBox668\" ID2=\"RefBox665\" TYPE=\"0\" /></ARROWS><BOXES><RBOX OID=\"RefBox653\" DX=\"0.0\" DY=\"0.0\" X=\"3.225\" Y=\"-4.766667\" REF=\"Process650\" TYPE=\"5\" REFNAME=\"Test_getPointOfIntrest\"><BOXES><RBOX OID=\"RefBox662\" DX=\"0.0\" DY=\"0.0\" X=\"4.525\" Y=\"-6.366667\" REF=\"InboxParameter655\" TYPE=\"4\" REFNAME=\"country\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox654\" DX=\"0.0\" DY=\"0.0\" X=\"4.6\" Y=\"-14.6\" REF=\"Process650\" TYPE=\"6\" REFNAME=\"Test_getPointOfIntrest\"><BOXES><RBOX OID=\"RefBox665\" DX=\"0.0\" DY=\"0.0\" X=\"5.325\" Y=\"-12.766666\" REF=\"OutboxParameter656\" TYPE=\"3\" REFNAME=\"POI_JSon\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox658\" DX=\"0.0\" DY=\"0.0\" X=\"4.275\" Y=\"-9.3\" REF=\"Activity657\" TYPE=\"0\" REFNAME=\"getPointOfIntrest\"><BOXES><RBOX OID=\"RefBox660\" DX=\"0.0\" DY=\"0.0\" X=\"4.675\" Y=\"-7.9\" REF=\"InboxParameter18\" TYPE=\"3\" REFNAME=\"country\"><BOXES /></RBOX><RBOX OID=\"RefBox668\" DX=\"0.0\" DY=\"0.0\" X=\"5.075\" Y=\"-11.233334\" REF=\"OutboxParameter417\" TYPE=\"9\" REFNAME=\"page\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program17\" NAME=\"getPointOfIntrest\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter18\" NAME=\"country\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter132\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getName() {  return "{TravelSuggestionoml}Test_getPointOfIntrest[1.0]";}

public String getPackage() {  return "TravelSuggestionoml";}

public String getVersion() {  return "1.0";}

public String getAuthor() {  return "";}

public String getDescription() {  return "Automatically generated test process for getPointOfIntrest";}

public String getCompileDate() {  return "2018-06-01 24:44:40.688";}

public Object getMetadata(String identifier) {
if ("ROUTER".equals(identifier)) {
return new Object[] {
new Object[] {new TID("{TravelSuggestionoml}Test_getPointOfIntrest[1.0].0.-2"), "1=1", "TravelSuggestionoml/Test_getPointOfIntrest/1.0"},
new Object[] {new TID("{TravelSuggestionoml}Test_getPointOfIntrest[1.0].0.-2"), "boolean(/Envelope/Body/Test_getPointOfIntrest)=true", "TravelSuggestionoml"}
};

}

else if ("WSDL".equals(identifier)) {
 return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<wsdl:definitions xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\" xmlns:apachesoap=\"http://xml.apache.org/xml-soap\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:typens=\"urn:/TravelSuggestionoml/Test_getPointOfIntrest/1.0\" xmlns:wsdlsoap=\"http://schemas.xmlsoap.org/wsdl/soap/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" name=\"/TravelSuggestionoml/Test_getPointOfIntrest/1.0Service\" targetNamespace=\"urn:/TravelSuggestionoml/Test_getPointOfIntrest/1.0\">\n  <wsdl:message name=\"Test_getPointOfIntrestInput\">\n    <wsdl:part name=\"country\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:message name=\"Test_getPointOfIntrestOutput\">\n    <wsdl:part name=\"POI_JSon\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:portType name=\"/TravelSuggestionoml/Test_getPointOfIntrest/1.0Port\">\n    <wsdl:operation name=\"Test_getPointOfIntrestRequest\">\n      <wsdl:input message=\"typens:Test_getPointOfIntrestInput\" />\n      <wsdl:output message=\"typens:Test_getPointOfIntrestOutput\" />\n    </wsdl:operation>\n  </wsdl:portType>\n  <wsdl:binding name=\"/TravelSuggestionoml/Test_getPointOfIntrest/1.0Binding\" type=\"typens:/TravelSuggestionoml/Test_getPointOfIntrest/1.0Port\">\n    <wsdlsoap:binding style=\"rpc\" transport=\"http://schemas.xmlsoap.org/soap/http\" />\n    <wsdl:operation name=\"Test_getPointOfIntrestRequest\">\n      <wsdlsoap:operation soapAction=\"urn:/TravelSuggestionoml/Test_getPointOfIntrest/1.0Action\" />\n      <wsdl:input>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_getPointOfIntrest/1.0\" use=\"encoded\" />\n      </wsdl:input>\n      <wsdl:output>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_getPointOfIntrest/1.0\" use=\"encoded\" />\n      </wsdl:output>\n    </wsdl:operation>\n  </wsdl:binding>\n  <wsdl:service name=\"/TravelSuggestionoml/Test_getPointOfIntrest/1.0Service\">\n    <wsdl:port binding=\"typens:/TravelSuggestionoml/Test_getPointOfIntrest/1.0Binding\" name=\"/TravelSuggestionoml/Test_getPointOfIntrest/1.0Port\">\n      <wsdlsoap:address location=\"http://@@LOCATION@@/services/TravelSuggestionoml/Test_getPointOfIntrest/1.0\" />\n    </wsdl:port>\n  </wsdl:service>\n</wsdl:definitions>";
}

else if ("REST.PUBLISHED".equals(identifier)) {
return "published"; 
}

return null;
}
public void SetupImage(TID Context, Map Params) { SetupSystemBox(PROC(Context));TID Context_PROC = PROC(Context);SetupParam(Context_PROC,Box.Input,"country",Params.get("country")==null?"":Params.get("country"));SetupParam(Context_PROC,Box.Output,"POI_JSon","");TimeStamp(Context_PROC,Box.ReadyTime);SetupgetPointOfIntrest(Context);}public void SetupgetPointOfIntrest(TID Context) {TID Context_TASK_getPointOfIntrest = TASK(Context,"getPointOfIntrest"); SetupSystemBox(Context_TASK_getPointOfIntrest);SetupParam(Context_TASK_getPointOfIntrest,Box.System,Box.Name,"getPointOfIntrest");SetupParam(Context_TASK_getPointOfIntrest,Box.System,Box.Type,Box.Activity);SetupParam(Context_TASK_getPointOfIntrest,Box.System,Box.Prog,"{TravelSuggestionoml}getPointOfIntrest[1.0]");SetupParam(Context_TASK_getPointOfIntrest,Box.Input,"country",null);SetupParam(Context_TASK_getPointOfIntrest,Box.Output,"POI_JSon",null);}public void Evaluate(TID Context) throws MemoryException {
if (log.isTraceEnabled()) {log.trace("Evaluate: " + Context + " " + Memory.getState(Context).toDebugString());}
boolean part_ok;int nc;Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = getResults();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);State State_PROC = Memory.getState(Context_PROC);
boolean changeCache = false;
TID Context_TASK_getPointOfIntrest = TASK(Context,"getPointOfIntrest"); State State_getPointOfIntrest = Memory.getState(Context_TASK_getPointOfIntrest);  if (State_PROC == State.INITIAL) {  TimeStamp(Context_PROC, Box.StartTime);  Exec.SetupTimeOut(Context_PROC);
// start task getPointOfIntrest
if (State_getPointOfIntrest == State.INITIAL) {Memory.Copy(MakeAddress(Context_PROC, Box.Input, "country"), MakeAddress(Context_TASK_getPointOfIntrest, Box.Input, "country"));
InputParams.clear();InputParams.put("country", Memory.Load(MakeAddress(Context_TASK_getPointOfIntrest, Box.Input, "country")));SystemInputParams.clear();TimeStamp(Context_TASK_getPointOfIntrest,Box.ReadyTime); Exec.Start(Context_TASK_getPointOfIntrest,InputParams,SystemInputParams);Memory.setState(Context_TASK_getPointOfIntrest,State.WAITING); State_getPointOfIntrest = State.WAITING;}if (Box.True.equals(Memory.Load(MakeAddress(Context_PROC, Box.System, Box.SuspendAfterCreation)))) {
Memory.setState(Context_PROC, State.SUSPENDED);
} else { Memory.setState(Context_PROC, State.RUNNING);}
} else {   State State_Context = Memory.getState(Context);   if ((State_PROC == State.RUNNING) || (State_Context == State.FINISHING) || (State_Context == State.FAILED) || (State_Context == State.UNREACHABLE) || (State_Context == State.SKIPPED)) {

// TASK: getPointOfIntrest

if (State_getPointOfIntrest == State.OUTPUTTING) {
Memory.setState(Context_TASK_getPointOfIntrest,State.RUNNING);
Exec.signalJob(Context_TASK_getPointOfIntrest,APIConsts.SIGNAL_UNBLOCK);
}
if (State_getPointOfIntrest == State.FINISHING) {
 Memory.Store(MakeAddress(Context_TASK_getPointOfIntrest,Box.Output,"POI_JSon"), (Serializable)Results.get("POI_JSon")); Memory.Copy(MakeAddress(Context_TASK_getPointOfIntrest, Box.SystemOutput, "page"), MakeAddress(Context_PROC, Box.Output, "POI_JSon"));
if (State_PROC == State.SUSPENDED) {
Memory.setState(Context_TASK_getPointOfIntrest,State.SUSPENDED_AFTER); State_getPointOfIntrest = State.SUSPENDED_AFTER;} else {
MemoryAddress stream_address = MakeAddress(Context_TASK_getPointOfIntrest, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_getPointOfIntrest,State.OUTPUTTING); State_getPointOfIntrest = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_getPointOfIntrest,State.FINISHED); State_getPointOfIntrest = State.FINISHED;}
} } else if (State_getPointOfIntrest == State.RESUMING_AFTER) {
MemoryAddress stream_address = MakeAddress(Context_TASK_getPointOfIntrest, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_getPointOfIntrest,State.OUTPUTTING); State_getPointOfIntrest = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_getPointOfIntrest,State.FINISHED); State_getPointOfIntrest = State.FINISHED;}
}
if (State_getPointOfIntrest == State.RUN) {
TimeStamp(Context_TASK_getPointOfIntrest,Box.StartTime);Memory.setState(Context_TASK_getPointOfIntrest,State.RUNNING);
State_getPointOfIntrest = State.RUNNING;
}
 if (( State_getPointOfIntrest.isFinishedOrUnreachableOrSkipped() )) { if (State_PROC != State.FINISHED) Memory.setState(Context_PROC, State.FINISHED);} if (( State_getPointOfIntrest == State.FAILED)) { if (State_PROC != State.FAILED) Memory.setState(Context_PROC, State.FAILED);} if (( State_getPointOfIntrest == State.ABORTED)) { if (State_PROC != State.ABORTED) Memory.setState(Context_PROC, State.ABORTED);} if (( State_getPointOfIntrest == State.SUSPENDED)) { if (State_PROC == State.RUNNING) Memory.setState(Context_PROC, State.SUSPENDED);} } if ((State_PROC == State.FINISHED) || (State_PROC == State.FAILED) || (State_PROC == State.ABORTED)) { Results.clear(); Results.put("POI_JSon",Memory.Load(MakeAddress(Context_PROC,Box.Output,"POI_JSon"))); Completed(Context_PROC, Results); } } }public void signalTasks(TID Context, int signal) throws MemoryException { SignalHandler sh = SignalHandler.getTaskSignalHandler(); sh.Signal(TASK(Context, "getPointOfIntrest"), signal); } 
public void StartTaskgetPointOfIntrest(TID Context) throws MemoryException {
int nc; boolean part_ok;
Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = new HashMap();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);
TID Context_TASK_getPointOfIntrest = TASK(Context,"getPointOfIntrest"); State State_getPointOfIntrest = Memory.getState(Context_TASK_getPointOfIntrest); Memory.Copy(MakeAddress(Context_PROC, Box.Input, "country"), MakeAddress(Context_TASK_getPointOfIntrest, Box.Input, "country"));
InputParams.clear();InputParams.put("country", Memory.Load(MakeAddress(Context_TASK_getPointOfIntrest, Box.Input, "country")));SystemInputParams.clear();TimeStamp(Context_TASK_getPointOfIntrest,Box.ReadyTime); Exec.Start(Context_TASK_getPointOfIntrest,InputParams,SystemInputParams);Memory.setState(Context_TASK_getPointOfIntrest,State.WAITING); State_getPointOfIntrest = State.WAITING;}

} //End of file