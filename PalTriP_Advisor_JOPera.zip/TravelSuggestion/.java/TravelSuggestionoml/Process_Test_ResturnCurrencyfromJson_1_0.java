//JOpera Process Template Plugin
//OML2Java Compiler Version 1.12 $Revision: 6795 $
package TravelSuggestionoml;import org.jopera.kernel.*;import org.jopera.kernel.api.APIConsts;import java.util.*;import java.io.Serializable;public class Process_Test_ResturnCurrencyfromJson_1_0 extends Template {public String getOMLPath() {  return "\\TravelSuggestion\\TravelSuggestionoml.oml";}

public String getOML() {  return "<PROCS><PROC OID=\"Process767\" NAME=\"Test_ResturnCurrencyfromJson\" DESC=\"Automatically generated test process for ResturnCurrencyfromJson\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter772\" NAME=\"POI_Json\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter773\" NAME=\"CurrencyDestenation\" DESC=\"\" TYPE=\"String\" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity774\" NAME=\"ResturnCurrencyfromJson\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program723\" /></TASKS><DATAFLOW><BIND OID=\"Binding780\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter772\" DESTPID=\"InboxParameter724\" DESTTID=\"Activity774\" ACTION=\"0\" /><BIND OID=\"Binding783\" SRCTYP=\"0\" DESTTYP=\"3\" SRCPID=\"OutboxParameter725\" DESTPID=\"OutboxParameter773\" SRCTID=\"Activity774\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View768\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox776\" X=\"0.0\" Y=\"50.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity774\" REFTYPE=\"0\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View769\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow781\" SOURCE=\"RefBox779\" DESTINATION=\"RefBox777\" REF=\"Binding780\" REFTYPE=\"1\" ROUTE=\"2\" /><ARROW OID=\"Arrow784\" SOURCE=\"RefBox778\" DESTINATION=\"RefBox782\" REF=\"Binding783\" REFTYPE=\"1\" ROUTE=\"2\" /></ARROWS><BOXES><RBOX OID=\"RefBox770\" X=\"250.0\" Y=\"24.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process767\" REFTYPE=\"5\"><BOXES><RBOX OID=\"RefBox779\" X=\"262.0\" Y=\"113.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter772\" REFTYPE=\"3\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox771\" X=\"398.0\" Y=\"554.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process767\" REFTYPE=\"6\"><BOXES><RBOX OID=\"RefBox782\" X=\"371.0\" Y=\"462.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter773\" REFTYPE=\"4\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox775\" X=\"392.0\" Y=\"260.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity774\" REFTYPE=\"0\"><BOXES><RBOX OID=\"RefBox777\" X=\"319.0\" Y=\"224.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter724\" REFTYPE=\"3\"><BOXES /></RBOX><RBOX OID=\"RefBox778\" X=\"279.0\" Y=\"352.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter725\" REFTYPE=\"4\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program723\" NAME=\"ResturnCurrencyfromJson\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter724\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter725\" NAME=\"CurrencyDestenation\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getOMLInterface() {  return "<PROCINTER><INBOX><PARAM OID=\"InboxParameter772\" NAME=\"POI_Json\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter773\" NAME=\"CurrencyDestenation\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROCINTER>";}

public String getOML1() {  return "<PROCS><PROC OID=\"Process767\" NAME=\"Test_ResturnCurrencyfromJson\" DESC=\"Automatically generated test process for ResturnCurrencyfromJson\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter772\" NAME=\"POI_Json\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter773\" NAME=\"CurrencyDestenation\" DESC=\"\" TYPE=\"String\" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity774\" NAME=\"ResturnCurrencyfromJson\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program723\" /></TASKS><DATAFLOW><BIND OID=\"Binding780\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter772\" DESTPID=\"InboxParameter724\" DESTTID=\"Activity774\" ACTION=\"0\" /><BIND OID=\"Binding783\" SRCTYP=\"0\" DESTTYP=\"3\" SRCPID=\"OutboxParameter725\" DESTPID=\"OutboxParameter773\" SRCTID=\"Activity774\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View768\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox776\" DX=\"0.0\" DY=\"0.0\" X=\"0.0\" Y=\"-1.6666666\" REF=\"Activity774\" TYPE=\"0\" REFNAME=\"ResturnCurrencyfromJson\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View769\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow781\" REF=\"Binding780\" ROUTE=\"2\" ID1=\"RefBox779\" ID2=\"RefBox777\" TYPE=\"0\" /><ARROW OID=\"Arrow784\" REF=\"Binding783\" ROUTE=\"2\" ID1=\"RefBox778\" ID2=\"RefBox782\" TYPE=\"0\" /></ARROWS><BOXES><RBOX OID=\"RefBox770\" DX=\"0.0\" DY=\"0.0\" X=\"6.25\" Y=\"-0.8\" REF=\"Process767\" TYPE=\"5\" REFNAME=\"Test_ResturnCurrencyfromJson\"><BOXES><RBOX OID=\"RefBox779\" DX=\"0.0\" DY=\"0.0\" X=\"6.55\" Y=\"-3.7666667\" REF=\"InboxParameter772\" TYPE=\"4\" REFNAME=\"POI_Json\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox771\" DX=\"0.0\" DY=\"0.0\" X=\"9.95\" Y=\"-18.466667\" REF=\"Process767\" TYPE=\"6\" REFNAME=\"Test_ResturnCurrencyfromJson\"><BOXES><RBOX OID=\"RefBox782\" DX=\"0.0\" DY=\"0.0\" X=\"9.275\" Y=\"-15.4\" REF=\"OutboxParameter773\" TYPE=\"3\" REFNAME=\"CurrencyDestenation\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox775\" DX=\"0.0\" DY=\"0.0\" X=\"9.8\" Y=\"-8.666667\" REF=\"Activity774\" TYPE=\"0\" REFNAME=\"ResturnCurrencyfromJson\"><BOXES><RBOX OID=\"RefBox777\" DX=\"0.0\" DY=\"0.0\" X=\"7.975\" Y=\"-7.4666667\" REF=\"InboxParameter724\" TYPE=\"3\" REFNAME=\"POI_JSon\"><BOXES /></RBOX><RBOX OID=\"RefBox778\" DX=\"0.0\" DY=\"0.0\" X=\"6.975\" Y=\"-11.733334\" REF=\"OutboxParameter725\" TYPE=\"4\" REFNAME=\"CurrencyDestenation\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program723\" NAME=\"ResturnCurrencyfromJson\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter724\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter725\" NAME=\"CurrencyDestenation\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getName() {  return "{TravelSuggestionoml}Test_ResturnCurrencyfromJson[1.0]";}

public String getPackage() {  return "TravelSuggestionoml";}

public String getVersion() {  return "1.0";}

public String getAuthor() {  return "";}

public String getDescription() {  return "Automatically generated test process for ResturnCurrencyfromJson";}

public String getCompileDate() {  return "2018-06-01 24:44:40.688";}

public Object getMetadata(String identifier) {
if ("ROUTER".equals(identifier)) {
return new Object[] {
new Object[] {new TID("{TravelSuggestionoml}Test_ResturnCurrencyfromJson[1.0].0.-2"), "1=1", "TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0"},
new Object[] {new TID("{TravelSuggestionoml}Test_ResturnCurrencyfromJson[1.0].0.-2"), "boolean(/Envelope/Body/Test_ResturnCurrencyfromJson)=true", "TravelSuggestionoml"}
};

}

else if ("WSDL".equals(identifier)) {
 return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<wsdl:definitions xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\" xmlns:apachesoap=\"http://xml.apache.org/xml-soap\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:typens=\"urn:/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0\" xmlns:wsdlsoap=\"http://schemas.xmlsoap.org/wsdl/soap/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" name=\"/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0Service\" targetNamespace=\"urn:/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0\">\n  <wsdl:message name=\"Test_ResturnCurrencyfromJsonInput\">\n    <wsdl:part name=\"POI_Json\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:message name=\"Test_ResturnCurrencyfromJsonOutput\">\n    <wsdl:part name=\"CurrencyDestenation\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:portType name=\"/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0Port\">\n    <wsdl:operation name=\"Test_ResturnCurrencyfromJsonRequest\">\n      <wsdl:input message=\"typens:Test_ResturnCurrencyfromJsonInput\" />\n      <wsdl:output message=\"typens:Test_ResturnCurrencyfromJsonOutput\" />\n    </wsdl:operation>\n  </wsdl:portType>\n  <wsdl:binding name=\"/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0Binding\" type=\"typens:/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0Port\">\n    <wsdlsoap:binding style=\"rpc\" transport=\"http://schemas.xmlsoap.org/soap/http\" />\n    <wsdl:operation name=\"Test_ResturnCurrencyfromJsonRequest\">\n      <wsdlsoap:operation soapAction=\"urn:/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0Action\" />\n      <wsdl:input>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0\" use=\"encoded\" />\n      </wsdl:input>\n      <wsdl:output>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0\" use=\"encoded\" />\n      </wsdl:output>\n    </wsdl:operation>\n  </wsdl:binding>\n  <wsdl:service name=\"/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0Service\">\n    <wsdl:port binding=\"typens:/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0Binding\" name=\"/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0Port\">\n      <wsdlsoap:address location=\"http://@@LOCATION@@/services/TravelSuggestionoml/Test_ResturnCurrencyfromJson/1.0\" />\n    </wsdl:port>\n  </wsdl:service>\n</wsdl:definitions>";
}

else if ("REST.PUBLISHED".equals(identifier)) {
return "published"; 
}

return null;
}
public void SetupImage(TID Context, Map Params) { SetupSystemBox(PROC(Context));TID Context_PROC = PROC(Context);SetupParam(Context_PROC,Box.Input,"POI_Json",Params.get("POI_Json")==null?"":Params.get("POI_Json"));SetupParam(Context_PROC,Box.Output,"CurrencyDestenation","");TimeStamp(Context_PROC,Box.ReadyTime);SetupResturnCurrencyfromJson(Context);}public void SetupResturnCurrencyfromJson(TID Context) {TID Context_TASK_ResturnCurrencyfromJson = TASK(Context,"ResturnCurrencyfromJson"); SetupSystemBox(Context_TASK_ResturnCurrencyfromJson);SetupParam(Context_TASK_ResturnCurrencyfromJson,Box.System,Box.Name,"ResturnCurrencyfromJson");SetupParam(Context_TASK_ResturnCurrencyfromJson,Box.System,Box.Type,Box.Activity);SetupParam(Context_TASK_ResturnCurrencyfromJson,Box.System,Box.Prog,"{TravelSuggestionoml}ResturnCurrencyfromJson[1.0]");SetupParam(Context_TASK_ResturnCurrencyfromJson,Box.Input,"POI_JSon",null);SetupParam(Context_TASK_ResturnCurrencyfromJson,Box.Output,"CurrencyDestenation",null);}public void Evaluate(TID Context) throws MemoryException {
if (log.isTraceEnabled()) {log.trace("Evaluate: " + Context + " " + Memory.getState(Context).toDebugString());}
boolean part_ok;int nc;Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = getResults();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);State State_PROC = Memory.getState(Context_PROC);
boolean changeCache = false;
TID Context_TASK_ResturnCurrencyfromJson = TASK(Context,"ResturnCurrencyfromJson"); State State_ResturnCurrencyfromJson = Memory.getState(Context_TASK_ResturnCurrencyfromJson);  if (State_PROC == State.INITIAL) {  TimeStamp(Context_PROC, Box.StartTime);  Exec.SetupTimeOut(Context_PROC);
// start task ResturnCurrencyfromJson
if (State_ResturnCurrencyfromJson == State.INITIAL) {Memory.Copy(MakeAddress(Context_PROC, Box.Input, "POI_Json"), MakeAddress(Context_TASK_ResturnCurrencyfromJson, Box.Input, "POI_JSon"));
InputParams.clear();InputParams.put("POI_JSon", Memory.Load(MakeAddress(Context_TASK_ResturnCurrencyfromJson, Box.Input, "POI_JSon")));SystemInputParams.clear();TimeStamp(Context_TASK_ResturnCurrencyfromJson,Box.ReadyTime); Exec.Start(Context_TASK_ResturnCurrencyfromJson,InputParams,SystemInputParams);Memory.setState(Context_TASK_ResturnCurrencyfromJson,State.WAITING); State_ResturnCurrencyfromJson = State.WAITING;}if (Box.True.equals(Memory.Load(MakeAddress(Context_PROC, Box.System, Box.SuspendAfterCreation)))) {
Memory.setState(Context_PROC, State.SUSPENDED);
} else { Memory.setState(Context_PROC, State.RUNNING);}
} else {   State State_Context = Memory.getState(Context);   if ((State_PROC == State.RUNNING) || (State_Context == State.FINISHING) || (State_Context == State.FAILED) || (State_Context == State.UNREACHABLE) || (State_Context == State.SKIPPED)) {

// TASK: ResturnCurrencyfromJson

if (State_ResturnCurrencyfromJson == State.OUTPUTTING) {
Memory.setState(Context_TASK_ResturnCurrencyfromJson,State.RUNNING);
Exec.signalJob(Context_TASK_ResturnCurrencyfromJson,APIConsts.SIGNAL_UNBLOCK);
}
if (State_ResturnCurrencyfromJson == State.FINISHING) {
 Memory.Store(MakeAddress(Context_TASK_ResturnCurrencyfromJson,Box.Output,"CurrencyDestenation"), (Serializable)Results.get("CurrencyDestenation")); Memory.Copy(MakeAddress(Context_TASK_ResturnCurrencyfromJson, Box.Output, "CurrencyDestenation"), MakeAddress(Context_PROC, Box.Output, "CurrencyDestenation"));
if (State_PROC == State.SUSPENDED) {
Memory.setState(Context_TASK_ResturnCurrencyfromJson,State.SUSPENDED_AFTER); State_ResturnCurrencyfromJson = State.SUSPENDED_AFTER;} else {
MemoryAddress stream_address = MakeAddress(Context_TASK_ResturnCurrencyfromJson, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_ResturnCurrencyfromJson,State.OUTPUTTING); State_ResturnCurrencyfromJson = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_ResturnCurrencyfromJson,State.FINISHED); State_ResturnCurrencyfromJson = State.FINISHED;}
} } else if (State_ResturnCurrencyfromJson == State.RESUMING_AFTER) {
MemoryAddress stream_address = MakeAddress(Context_TASK_ResturnCurrencyfromJson, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_ResturnCurrencyfromJson,State.OUTPUTTING); State_ResturnCurrencyfromJson = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_ResturnCurrencyfromJson,State.FINISHED); State_ResturnCurrencyfromJson = State.FINISHED;}
}
if (State_ResturnCurrencyfromJson == State.RUN) {
TimeStamp(Context_TASK_ResturnCurrencyfromJson,Box.StartTime);Memory.setState(Context_TASK_ResturnCurrencyfromJson,State.RUNNING);
State_ResturnCurrencyfromJson = State.RUNNING;
}
 if (( State_ResturnCurrencyfromJson.isFinishedOrUnreachableOrSkipped() )) { if (State_PROC != State.FINISHED) Memory.setState(Context_PROC, State.FINISHED);} if (( State_ResturnCurrencyfromJson == State.FAILED)) { if (State_PROC != State.FAILED) Memory.setState(Context_PROC, State.FAILED);} if (( State_ResturnCurrencyfromJson == State.ABORTED)) { if (State_PROC != State.ABORTED) Memory.setState(Context_PROC, State.ABORTED);} if (( State_ResturnCurrencyfromJson == State.SUSPENDED)) { if (State_PROC == State.RUNNING) Memory.setState(Context_PROC, State.SUSPENDED);} } if ((State_PROC == State.FINISHED) || (State_PROC == State.FAILED) || (State_PROC == State.ABORTED)) { Results.clear(); Results.put("CurrencyDestenation",Memory.Load(MakeAddress(Context_PROC,Box.Output,"CurrencyDestenation"))); Completed(Context_PROC, Results); } } }public void signalTasks(TID Context, int signal) throws MemoryException { SignalHandler sh = SignalHandler.getTaskSignalHandler(); sh.Signal(TASK(Context, "ResturnCurrencyfromJson"), signal); } 
public void StartTaskResturnCurrencyfromJson(TID Context) throws MemoryException {
int nc; boolean part_ok;
Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = new HashMap();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);
TID Context_TASK_ResturnCurrencyfromJson = TASK(Context,"ResturnCurrencyfromJson"); State State_ResturnCurrencyfromJson = Memory.getState(Context_TASK_ResturnCurrencyfromJson); Memory.Copy(MakeAddress(Context_PROC, Box.Input, "POI_Json"), MakeAddress(Context_TASK_ResturnCurrencyfromJson, Box.Input, "POI_JSon"));
InputParams.clear();InputParams.put("POI_JSon", Memory.Load(MakeAddress(Context_TASK_ResturnCurrencyfromJson, Box.Input, "POI_JSon")));SystemInputParams.clear();TimeStamp(Context_TASK_ResturnCurrencyfromJson,Box.ReadyTime); Exec.Start(Context_TASK_ResturnCurrencyfromJson,InputParams,SystemInputParams);Memory.setState(Context_TASK_ResturnCurrencyfromJson,State.WAITING); State_ResturnCurrencyfromJson = State.WAITING;}

} //End of file