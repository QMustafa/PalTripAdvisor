//JOpera Process Template Plugin
//OML2Java Compiler Version 1.12 $Revision: 6795 $
package TravelSuggestionoml;import org.jopera.kernel.*;import org.jopera.kernel.api.APIConsts;import java.util.*;import java.io.Serializable;public class Process_Test_getCloseHotel_1_0 extends Template {public String getOMLPath() {  return "\\TravelSuggestion\\TravelSuggestionoml.oml";}

public String getOML() {  return "<PROCS><PROC OID=\"Process524\" NAME=\"Test_getCloseHotel\" DESC=\"Automatically generated test process for getCloseHotel\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter529\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter530\" NAME=\"listOfHotel\" DESC=\"\" TYPE=\"Sting \" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity531\" NAME=\"getCloseHotel\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program45\" /></TASKS><DATAFLOW><BIND OID=\"Binding537\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter529\" DESTPID=\"InboxParameter46\" DESTTID=\"Activity531\" ACTION=\"0\" /><BIND OID=\"Binding540\" SRCTYP=\"0\" DESTTYP=\"3\" SRCPID=\"OutboxParameter239\" DESTPID=\"OutboxParameter530\" SRCTID=\"Activity531\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View525\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox533\" X=\"0.0\" Y=\"50.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity531\" REFTYPE=\"0\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View526\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow538\" SOURCE=\"RefBox536\" DESTINATION=\"RefBox534\" REF=\"Binding537\" REFTYPE=\"1\" ROUTE=\"2\" /><ARROW OID=\"Arrow541\" SOURCE=\"RefBox535\" DESTINATION=\"RefBox539\" REF=\"Binding540\" REFTYPE=\"1\" ROUTE=\"2\" /></ARROWS><BOXES><RBOX OID=\"RefBox527\" X=\"250.0\" Y=\"0.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process524\" REFTYPE=\"5\"><BOXES><RBOX OID=\"RefBox536\" X=\"250.0\" Y=\"50.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter529\" REFTYPE=\"3\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox528\" X=\"450.0\" Y=\"700.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process524\" REFTYPE=\"6\"><BOXES><RBOX OID=\"RefBox539\" X=\"450.0\" Y=\"640.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter530\" REFTYPE=\"4\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox532\" X=\"350.0\" Y=\"350.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity531\" REFTYPE=\"0\"><BOXES><RBOX OID=\"RefBox534\" X=\"325.0\" Y=\"300.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter46\" REFTYPE=\"3\"><BOXES /></RBOX><RBOX OID=\"RefBox535\" X=\"325.0\" Y=\"410.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter239\" REFTYPE=\"4\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program45\" NAME=\"getCloseHotel\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter46\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter239\" NAME=\"listOfHotel\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getOMLInterface() {  return "<PROCINTER><INBOX><PARAM OID=\"InboxParameter529\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter530\" NAME=\"listOfHotel\" DESC=\"\" TYPE=\"Sting \" /></OUTBOX></PROCINTER>";}

public String getOML1() {  return "<PROCS><PROC OID=\"Process524\" NAME=\"Test_getCloseHotel\" DESC=\"Automatically generated test process for getCloseHotel\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter529\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter530\" NAME=\"listOfHotel\" DESC=\"\" TYPE=\"Sting \" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity531\" NAME=\"getCloseHotel\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program45\" /></TASKS><DATAFLOW><BIND OID=\"Binding537\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter529\" DESTPID=\"InboxParameter46\" DESTTID=\"Activity531\" ACTION=\"0\" /><BIND OID=\"Binding540\" SRCTYP=\"0\" DESTTYP=\"3\" SRCPID=\"OutboxParameter239\" DESTPID=\"OutboxParameter530\" SRCTID=\"Activity531\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View525\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox533\" DX=\"0.0\" DY=\"0.0\" X=\"0.0\" Y=\"-1.6666666\" REF=\"Activity531\" TYPE=\"0\" REFNAME=\"getCloseHotel\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View526\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow538\" REF=\"Binding537\" ROUTE=\"2\" ID1=\"RefBox536\" ID2=\"RefBox534\" TYPE=\"0\" /><ARROW OID=\"Arrow541\" REF=\"Binding540\" ROUTE=\"2\" ID1=\"RefBox535\" ID2=\"RefBox539\" TYPE=\"0\" /></ARROWS><BOXES><RBOX OID=\"RefBox527\" DX=\"0.0\" DY=\"0.0\" X=\"6.25\" Y=\"-0.0\" REF=\"Process524\" TYPE=\"5\" REFNAME=\"Test_getCloseHotel\"><BOXES><RBOX OID=\"RefBox536\" DX=\"0.0\" DY=\"0.0\" X=\"6.25\" Y=\"-1.6666666\" REF=\"InboxParameter529\" TYPE=\"4\" REFNAME=\"City\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox528\" DX=\"0.0\" DY=\"0.0\" X=\"11.25\" Y=\"-23.333334\" REF=\"Process524\" TYPE=\"6\" REFNAME=\"Test_getCloseHotel\"><BOXES><RBOX OID=\"RefBox539\" DX=\"0.0\" DY=\"0.0\" X=\"11.25\" Y=\"-21.333334\" REF=\"OutboxParameter530\" TYPE=\"3\" REFNAME=\"listOfHotel\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox532\" DX=\"0.0\" DY=\"0.0\" X=\"8.75\" Y=\"-11.666667\" REF=\"Activity531\" TYPE=\"0\" REFNAME=\"getCloseHotel\"><BOXES><RBOX OID=\"RefBox534\" DX=\"0.0\" DY=\"0.0\" X=\"8.125\" Y=\"-10.0\" REF=\"InboxParameter46\" TYPE=\"3\" REFNAME=\"City\"><BOXES /></RBOX><RBOX OID=\"RefBox535\" DX=\"0.0\" DY=\"0.0\" X=\"8.125\" Y=\"-13.666667\" REF=\"OutboxParameter239\" TYPE=\"4\" REFNAME=\"listOfHotel\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program45\" NAME=\"getCloseHotel\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter46\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter239\" NAME=\"listOfHotel\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getName() {  return "{TravelSuggestionoml}Test_getCloseHotel[1.0]";}

public String getPackage() {  return "TravelSuggestionoml";}

public String getVersion() {  return "1.0";}

public String getAuthor() {  return "";}

public String getDescription() {  return "Automatically generated test process for getCloseHotel";}

public String getCompileDate() {  return "2018-06-01 24:44:40.672";}

public Object getMetadata(String identifier) {
if ("ROUTER".equals(identifier)) {
return new Object[] {
new Object[] {new TID("{TravelSuggestionoml}Test_getCloseHotel[1.0].0.-2"), "1=1", "TravelSuggestionoml/Test_getCloseHotel/1.0"},
new Object[] {new TID("{TravelSuggestionoml}Test_getCloseHotel[1.0].0.-2"), "boolean(/Envelope/Body/Test_getCloseHotel)=true", "TravelSuggestionoml"}
};

}

else if ("WSDL".equals(identifier)) {
 return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<wsdl:definitions xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\" xmlns:apachesoap=\"http://xml.apache.org/xml-soap\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:typens=\"urn:/TravelSuggestionoml/Test_getCloseHotel/1.0\" xmlns:wsdlsoap=\"http://schemas.xmlsoap.org/wsdl/soap/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" name=\"/TravelSuggestionoml/Test_getCloseHotel/1.0Service\" targetNamespace=\"urn:/TravelSuggestionoml/Test_getCloseHotel/1.0\">\n  <wsdl:message name=\"Test_getCloseHotelOutput\">\n    <wsdl:part name=\"listOfHotel\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:message name=\"Test_getCloseHotelInput\">\n    <wsdl:part name=\"City\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:portType name=\"/TravelSuggestionoml/Test_getCloseHotel/1.0Port\">\n    <wsdl:operation name=\"Test_getCloseHotelRequest\">\n      <wsdl:input message=\"typens:Test_getCloseHotelInput\" />\n      <wsdl:output message=\"typens:Test_getCloseHotelOutput\" />\n    </wsdl:operation>\n  </wsdl:portType>\n  <wsdl:binding name=\"/TravelSuggestionoml/Test_getCloseHotel/1.0Binding\" type=\"typens:/TravelSuggestionoml/Test_getCloseHotel/1.0Port\">\n    <wsdlsoap:binding style=\"rpc\" transport=\"http://schemas.xmlsoap.org/soap/http\" />\n    <wsdl:operation name=\"Test_getCloseHotelRequest\">\n      <wsdlsoap:operation soapAction=\"urn:/TravelSuggestionoml/Test_getCloseHotel/1.0Action\" />\n      <wsdl:input>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_getCloseHotel/1.0\" use=\"encoded\" />\n      </wsdl:input>\n      <wsdl:output>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_getCloseHotel/1.0\" use=\"encoded\" />\n      </wsdl:output>\n    </wsdl:operation>\n  </wsdl:binding>\n  <wsdl:service name=\"/TravelSuggestionoml/Test_getCloseHotel/1.0Service\">\n    <wsdl:port binding=\"typens:/TravelSuggestionoml/Test_getCloseHotel/1.0Binding\" name=\"/TravelSuggestionoml/Test_getCloseHotel/1.0Port\">\n      <wsdlsoap:address location=\"http://@@LOCATION@@/services/TravelSuggestionoml/Test_getCloseHotel/1.0\" />\n    </wsdl:port>\n  </wsdl:service>\n</wsdl:definitions>";
}

else if ("REST.PUBLISHED".equals(identifier)) {
return "published"; 
}

return null;
}
public void SetupImage(TID Context, Map Params) { SetupSystemBox(PROC(Context));TID Context_PROC = PROC(Context);SetupParam(Context_PROC,Box.Input,"City",Params.get("City")==null?"":Params.get("City"));SetupParam(Context_PROC,Box.Output,"listOfHotel","");TimeStamp(Context_PROC,Box.ReadyTime);SetupgetCloseHotel(Context);}public void SetupgetCloseHotel(TID Context) {TID Context_TASK_getCloseHotel = TASK(Context,"getCloseHotel"); SetupSystemBox(Context_TASK_getCloseHotel);SetupParam(Context_TASK_getCloseHotel,Box.System,Box.Name,"getCloseHotel");SetupParam(Context_TASK_getCloseHotel,Box.System,Box.Type,Box.Activity);SetupParam(Context_TASK_getCloseHotel,Box.System,Box.Prog,"{TravelSuggestionoml}getCloseHotel[1.0]");SetupParam(Context_TASK_getCloseHotel,Box.Input,"City",null);SetupParam(Context_TASK_getCloseHotel,Box.Output,"listOfHotel",null);}public void Evaluate(TID Context) throws MemoryException {
if (log.isTraceEnabled()) {log.trace("Evaluate: " + Context + " " + Memory.getState(Context).toDebugString());}
boolean part_ok;int nc;Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = getResults();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);State State_PROC = Memory.getState(Context_PROC);
boolean changeCache = false;
TID Context_TASK_getCloseHotel = TASK(Context,"getCloseHotel"); State State_getCloseHotel = Memory.getState(Context_TASK_getCloseHotel);  if (State_PROC == State.INITIAL) {  TimeStamp(Context_PROC, Box.StartTime);  Exec.SetupTimeOut(Context_PROC);
// start task getCloseHotel
if (State_getCloseHotel == State.INITIAL) {Memory.Copy(MakeAddress(Context_PROC, Box.Input, "City"), MakeAddress(Context_TASK_getCloseHotel, Box.Input, "City"));
InputParams.clear();InputParams.put("City", Memory.Load(MakeAddress(Context_TASK_getCloseHotel, Box.Input, "City")));SystemInputParams.clear();TimeStamp(Context_TASK_getCloseHotel,Box.ReadyTime); Exec.Start(Context_TASK_getCloseHotel,InputParams,SystemInputParams);Memory.setState(Context_TASK_getCloseHotel,State.WAITING); State_getCloseHotel = State.WAITING;}if (Box.True.equals(Memory.Load(MakeAddress(Context_PROC, Box.System, Box.SuspendAfterCreation)))) {
Memory.setState(Context_PROC, State.SUSPENDED);
} else { Memory.setState(Context_PROC, State.RUNNING);}
} else {   State State_Context = Memory.getState(Context);   if ((State_PROC == State.RUNNING) || (State_Context == State.FINISHING) || (State_Context == State.FAILED) || (State_Context == State.UNREACHABLE) || (State_Context == State.SKIPPED)) {

// TASK: getCloseHotel

if (State_getCloseHotel == State.OUTPUTTING) {
Memory.setState(Context_TASK_getCloseHotel,State.RUNNING);
Exec.signalJob(Context_TASK_getCloseHotel,APIConsts.SIGNAL_UNBLOCK);
}
if (State_getCloseHotel == State.FINISHING) {
 Memory.Store(MakeAddress(Context_TASK_getCloseHotel,Box.Output,"listOfHotel"), (Serializable)Results.get("listOfHotel")); Memory.Copy(MakeAddress(Context_TASK_getCloseHotel, Box.Output, "listOfHotel"), MakeAddress(Context_PROC, Box.Output, "listOfHotel"));
if (State_PROC == State.SUSPENDED) {
Memory.setState(Context_TASK_getCloseHotel,State.SUSPENDED_AFTER); State_getCloseHotel = State.SUSPENDED_AFTER;} else {
MemoryAddress stream_address = MakeAddress(Context_TASK_getCloseHotel, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_getCloseHotel,State.OUTPUTTING); State_getCloseHotel = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_getCloseHotel,State.FINISHED); State_getCloseHotel = State.FINISHED;}
} } else if (State_getCloseHotel == State.RESUMING_AFTER) {
MemoryAddress stream_address = MakeAddress(Context_TASK_getCloseHotel, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_getCloseHotel,State.OUTPUTTING); State_getCloseHotel = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_getCloseHotel,State.FINISHED); State_getCloseHotel = State.FINISHED;}
}
if (State_getCloseHotel == State.RUN) {
TimeStamp(Context_TASK_getCloseHotel,Box.StartTime);Memory.setState(Context_TASK_getCloseHotel,State.RUNNING);
State_getCloseHotel = State.RUNNING;
}
 if (( State_getCloseHotel.isFinishedOrUnreachableOrSkipped() )) { if (State_PROC != State.FINISHED) Memory.setState(Context_PROC, State.FINISHED);} if (( State_getCloseHotel == State.FAILED)) { if (State_PROC != State.FAILED) Memory.setState(Context_PROC, State.FAILED);} if (( State_getCloseHotel == State.ABORTED)) { if (State_PROC != State.ABORTED) Memory.setState(Context_PROC, State.ABORTED);} if (( State_getCloseHotel == State.SUSPENDED)) { if (State_PROC == State.RUNNING) Memory.setState(Context_PROC, State.SUSPENDED);} } if ((State_PROC == State.FINISHED) || (State_PROC == State.FAILED) || (State_PROC == State.ABORTED)) { Results.clear(); Results.put("listOfHotel",Memory.Load(MakeAddress(Context_PROC,Box.Output,"listOfHotel"))); Completed(Context_PROC, Results); } } }public void signalTasks(TID Context, int signal) throws MemoryException { SignalHandler sh = SignalHandler.getTaskSignalHandler(); sh.Signal(TASK(Context, "getCloseHotel"), signal); } 
public void StartTaskgetCloseHotel(TID Context) throws MemoryException {
int nc; boolean part_ok;
Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = new HashMap();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);
TID Context_TASK_getCloseHotel = TASK(Context,"getCloseHotel"); State State_getCloseHotel = Memory.getState(Context_TASK_getCloseHotel); Memory.Copy(MakeAddress(Context_PROC, Box.Input, "City"), MakeAddress(Context_TASK_getCloseHotel, Box.Input, "City"));
InputParams.clear();InputParams.put("City", Memory.Load(MakeAddress(Context_TASK_getCloseHotel, Box.Input, "City")));SystemInputParams.clear();TimeStamp(Context_TASK_getCloseHotel,Box.ReadyTime); Exec.Start(Context_TASK_getCloseHotel,InputParams,SystemInputParams);Memory.setState(Context_TASK_getCloseHotel,State.WAITING); State_getCloseHotel = State.WAITING;}

} //End of file