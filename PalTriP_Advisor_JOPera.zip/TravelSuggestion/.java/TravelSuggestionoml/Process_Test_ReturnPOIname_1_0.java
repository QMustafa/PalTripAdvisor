//JOpera Process Template Plugin
//OML2Java Compiler Version 1.12 $Revision: 6795 $
package TravelSuggestionoml;import org.jopera.kernel.*;import org.jopera.kernel.api.APIConsts;import java.util.*;import java.io.Serializable;public class Process_Test_ReturnPOIname_1_0 extends Template {public String getOMLPath() {  return "\\TravelSuggestion\\TravelSuggestionoml.oml";}

public String getOML() {  return "<PROCS><PROC OID=\"Process973\" NAME=\"Test_ReturnPOIname\" DESC=\"Automatically generated test process for ReturnPOIname\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter978\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter979\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity980\" NAME=\"ReturnPOIname\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program697\" /></TASKS><DATAFLOW><BIND OID=\"Binding986\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter978\" DESTPID=\"InboxParameter698\" DESTTID=\"Activity980\" ACTION=\"0\" /><BIND OID=\"Binding989\" SRCTYP=\"0\" DESTTYP=\"3\" SRCPID=\"OutboxParameter699\" DESTPID=\"OutboxParameter979\" SRCTID=\"Activity980\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View974\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox982\" X=\"0.0\" Y=\"50.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity980\" REFTYPE=\"0\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View975\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow987\" SOURCE=\"RefBox985\" DESTINATION=\"RefBox983\" REF=\"Binding986\" REFTYPE=\"1\" ROUTE=\"2\" /><ARROW OID=\"Arrow990\" SOURCE=\"RefBox984\" DESTINATION=\"RefBox988\" REF=\"Binding989\" REFTYPE=\"1\" ROUTE=\"2\" /></ARROWS><BOXES><RBOX OID=\"RefBox976\" X=\"250.0\" Y=\"0.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process973\" REFTYPE=\"5\"><BOXES><RBOX OID=\"RefBox985\" X=\"250.0\" Y=\"50.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter978\" REFTYPE=\"3\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox977\" X=\"450.0\" Y=\"700.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process973\" REFTYPE=\"6\"><BOXES><RBOX OID=\"RefBox988\" X=\"450.0\" Y=\"640.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter979\" REFTYPE=\"4\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox981\" X=\"350.0\" Y=\"350.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity980\" REFTYPE=\"0\"><BOXES><RBOX OID=\"RefBox983\" X=\"325.0\" Y=\"300.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter698\" REFTYPE=\"3\"><BOXES /></RBOX><RBOX OID=\"RefBox984\" X=\"325.0\" Y=\"410.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter699\" REFTYPE=\"4\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program697\" NAME=\"ReturnPOIname\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter698\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter699\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getOMLInterface() {  return "<PROCINTER><INBOX><PARAM OID=\"InboxParameter978\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter979\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROCINTER>";}

public String getOML1() {  return "<PROCS><PROC OID=\"Process973\" NAME=\"Test_ReturnPOIname\" DESC=\"Automatically generated test process for ReturnPOIname\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter978\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter979\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity980\" NAME=\"ReturnPOIname\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program697\" /></TASKS><DATAFLOW><BIND OID=\"Binding986\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter978\" DESTPID=\"InboxParameter698\" DESTTID=\"Activity980\" ACTION=\"0\" /><BIND OID=\"Binding989\" SRCTYP=\"0\" DESTTYP=\"3\" SRCPID=\"OutboxParameter699\" DESTPID=\"OutboxParameter979\" SRCTID=\"Activity980\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View974\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox982\" DX=\"0.0\" DY=\"0.0\" X=\"0.0\" Y=\"-1.6666666\" REF=\"Activity980\" TYPE=\"0\" REFNAME=\"ReturnPOIname\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View975\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow987\" REF=\"Binding986\" ROUTE=\"2\" ID1=\"RefBox985\" ID2=\"RefBox983\" TYPE=\"0\" /><ARROW OID=\"Arrow990\" REF=\"Binding989\" ROUTE=\"2\" ID1=\"RefBox984\" ID2=\"RefBox988\" TYPE=\"0\" /></ARROWS><BOXES><RBOX OID=\"RefBox976\" DX=\"0.0\" DY=\"0.0\" X=\"6.25\" Y=\"-0.0\" REF=\"Process973\" TYPE=\"5\" REFNAME=\"Test_ReturnPOIname\"><BOXES><RBOX OID=\"RefBox985\" DX=\"0.0\" DY=\"0.0\" X=\"6.25\" Y=\"-1.6666666\" REF=\"InboxParameter978\" TYPE=\"4\" REFNAME=\"POI_JSon\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox977\" DX=\"0.0\" DY=\"0.0\" X=\"11.25\" Y=\"-23.333334\" REF=\"Process973\" TYPE=\"6\" REFNAME=\"Test_ReturnPOIname\"><BOXES><RBOX OID=\"RefBox988\" DX=\"0.0\" DY=\"0.0\" X=\"11.25\" Y=\"-21.333334\" REF=\"OutboxParameter979\" TYPE=\"3\" REFNAME=\"City\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox981\" DX=\"0.0\" DY=\"0.0\" X=\"8.75\" Y=\"-11.666667\" REF=\"Activity980\" TYPE=\"0\" REFNAME=\"ReturnPOIname\"><BOXES><RBOX OID=\"RefBox983\" DX=\"0.0\" DY=\"0.0\" X=\"8.125\" Y=\"-10.0\" REF=\"InboxParameter698\" TYPE=\"3\" REFNAME=\"POI_JSon\"><BOXES /></RBOX><RBOX OID=\"RefBox984\" DX=\"0.0\" DY=\"0.0\" X=\"8.125\" Y=\"-13.666667\" REF=\"OutboxParameter699\" TYPE=\"4\" REFNAME=\"City\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program697\" NAME=\"ReturnPOIname\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter698\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter699\" NAME=\"City\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getName() {  return "{TravelSuggestionoml}Test_ReturnPOIname[1.0]";}

public String getPackage() {  return "TravelSuggestionoml";}

public String getVersion() {  return "1.0";}

public String getAuthor() {  return "";}

public String getDescription() {  return "Automatically generated test process for ReturnPOIname";}

public String getCompileDate() {  return "2018-06-01 24:44:40.703";}

public Object getMetadata(String identifier) {
if ("ROUTER".equals(identifier)) {
return new Object[] {
new Object[] {new TID("{TravelSuggestionoml}Test_ReturnPOIname[1.0].0.-2"), "1=1", "TravelSuggestionoml/Test_ReturnPOIname/1.0"},
new Object[] {new TID("{TravelSuggestionoml}Test_ReturnPOIname[1.0].0.-2"), "boolean(/Envelope/Body/Test_ReturnPOIname)=true", "TravelSuggestionoml"}
};

}

else if ("WSDL".equals(identifier)) {
 return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<wsdl:definitions xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\" xmlns:apachesoap=\"http://xml.apache.org/xml-soap\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:typens=\"urn:/TravelSuggestionoml/Test_ReturnPOIname/1.0\" xmlns:wsdlsoap=\"http://schemas.xmlsoap.org/wsdl/soap/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" name=\"/TravelSuggestionoml/Test_ReturnPOIname/1.0Service\" targetNamespace=\"urn:/TravelSuggestionoml/Test_ReturnPOIname/1.0\">\n  <wsdl:message name=\"Test_ReturnPOInameInput\">\n    <wsdl:part name=\"POI_JSon\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:message name=\"Test_ReturnPOInameOutput\">\n    <wsdl:part name=\"City\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:portType name=\"/TravelSuggestionoml/Test_ReturnPOIname/1.0Port\">\n    <wsdl:operation name=\"Test_ReturnPOInameRequest\">\n      <wsdl:input message=\"typens:Test_ReturnPOInameInput\" />\n      <wsdl:output message=\"typens:Test_ReturnPOInameOutput\" />\n    </wsdl:operation>\n  </wsdl:portType>\n  <wsdl:binding name=\"/TravelSuggestionoml/Test_ReturnPOIname/1.0Binding\" type=\"typens:/TravelSuggestionoml/Test_ReturnPOIname/1.0Port\">\n    <wsdlsoap:binding style=\"rpc\" transport=\"http://schemas.xmlsoap.org/soap/http\" />\n    <wsdl:operation name=\"Test_ReturnPOInameRequest\">\n      <wsdlsoap:operation soapAction=\"urn:/TravelSuggestionoml/Test_ReturnPOIname/1.0Action\" />\n      <wsdl:input>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_ReturnPOIname/1.0\" use=\"encoded\" />\n      </wsdl:input>\n      <wsdl:output>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_ReturnPOIname/1.0\" use=\"encoded\" />\n      </wsdl:output>\n    </wsdl:operation>\n  </wsdl:binding>\n  <wsdl:service name=\"/TravelSuggestionoml/Test_ReturnPOIname/1.0Service\">\n    <wsdl:port binding=\"typens:/TravelSuggestionoml/Test_ReturnPOIname/1.0Binding\" name=\"/TravelSuggestionoml/Test_ReturnPOIname/1.0Port\">\n      <wsdlsoap:address location=\"http://@@LOCATION@@/services/TravelSuggestionoml/Test_ReturnPOIname/1.0\" />\n    </wsdl:port>\n  </wsdl:service>\n</wsdl:definitions>";
}

else if ("REST.PUBLISHED".equals(identifier)) {
return "published"; 
}

return null;
}
public void SetupImage(TID Context, Map Params) { SetupSystemBox(PROC(Context));TID Context_PROC = PROC(Context);SetupParam(Context_PROC,Box.Input,"POI_JSon",Params.get("POI_JSon")==null?"":Params.get("POI_JSon"));SetupParam(Context_PROC,Box.Output,"City","");TimeStamp(Context_PROC,Box.ReadyTime);SetupReturnPOIname(Context);}public void SetupReturnPOIname(TID Context) {TID Context_TASK_ReturnPOIname = TASK(Context,"ReturnPOIname"); SetupSystemBox(Context_TASK_ReturnPOIname);SetupParam(Context_TASK_ReturnPOIname,Box.System,Box.Name,"ReturnPOIname");SetupParam(Context_TASK_ReturnPOIname,Box.System,Box.Type,Box.Activity);SetupParam(Context_TASK_ReturnPOIname,Box.System,Box.Prog,"{TravelSuggestionoml}ReturnPOIname[1.0]");SetupParam(Context_TASK_ReturnPOIname,Box.Input,"POI_JSon",null);SetupParam(Context_TASK_ReturnPOIname,Box.Output,"City",null);}public void Evaluate(TID Context) throws MemoryException {
if (log.isTraceEnabled()) {log.trace("Evaluate: " + Context + " " + Memory.getState(Context).toDebugString());}
boolean part_ok;int nc;Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = getResults();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);State State_PROC = Memory.getState(Context_PROC);
boolean changeCache = false;
TID Context_TASK_ReturnPOIname = TASK(Context,"ReturnPOIname"); State State_ReturnPOIname = Memory.getState(Context_TASK_ReturnPOIname);  if (State_PROC == State.INITIAL) {  TimeStamp(Context_PROC, Box.StartTime);  Exec.SetupTimeOut(Context_PROC);
// start task ReturnPOIname
if (State_ReturnPOIname == State.INITIAL) {Memory.Copy(MakeAddress(Context_PROC, Box.Input, "POI_JSon"), MakeAddress(Context_TASK_ReturnPOIname, Box.Input, "POI_JSon"));
InputParams.clear();InputParams.put("POI_JSon", Memory.Load(MakeAddress(Context_TASK_ReturnPOIname, Box.Input, "POI_JSon")));SystemInputParams.clear();TimeStamp(Context_TASK_ReturnPOIname,Box.ReadyTime); Exec.Start(Context_TASK_ReturnPOIname,InputParams,SystemInputParams);Memory.setState(Context_TASK_ReturnPOIname,State.WAITING); State_ReturnPOIname = State.WAITING;}if (Box.True.equals(Memory.Load(MakeAddress(Context_PROC, Box.System, Box.SuspendAfterCreation)))) {
Memory.setState(Context_PROC, State.SUSPENDED);
} else { Memory.setState(Context_PROC, State.RUNNING);}
} else {   State State_Context = Memory.getState(Context);   if ((State_PROC == State.RUNNING) || (State_Context == State.FINISHING) || (State_Context == State.FAILED) || (State_Context == State.UNREACHABLE) || (State_Context == State.SKIPPED)) {

// TASK: ReturnPOIname

if (State_ReturnPOIname == State.OUTPUTTING) {
Memory.setState(Context_TASK_ReturnPOIname,State.RUNNING);
Exec.signalJob(Context_TASK_ReturnPOIname,APIConsts.SIGNAL_UNBLOCK);
}
if (State_ReturnPOIname == State.FINISHING) {
 Memory.Store(MakeAddress(Context_TASK_ReturnPOIname,Box.Output,"City"), (Serializable)Results.get("City")); Memory.Copy(MakeAddress(Context_TASK_ReturnPOIname, Box.Output, "City"), MakeAddress(Context_PROC, Box.Output, "City"));
if (State_PROC == State.SUSPENDED) {
Memory.setState(Context_TASK_ReturnPOIname,State.SUSPENDED_AFTER); State_ReturnPOIname = State.SUSPENDED_AFTER;} else {
MemoryAddress stream_address = MakeAddress(Context_TASK_ReturnPOIname, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_ReturnPOIname,State.OUTPUTTING); State_ReturnPOIname = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_ReturnPOIname,State.FINISHED); State_ReturnPOIname = State.FINISHED;}
} } else if (State_ReturnPOIname == State.RESUMING_AFTER) {
MemoryAddress stream_address = MakeAddress(Context_TASK_ReturnPOIname, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_ReturnPOIname,State.OUTPUTTING); State_ReturnPOIname = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_ReturnPOIname,State.FINISHED); State_ReturnPOIname = State.FINISHED;}
}
if (State_ReturnPOIname == State.RUN) {
TimeStamp(Context_TASK_ReturnPOIname,Box.StartTime);Memory.setState(Context_TASK_ReturnPOIname,State.RUNNING);
State_ReturnPOIname = State.RUNNING;
}
 if (( State_ReturnPOIname.isFinishedOrUnreachableOrSkipped() )) { if (State_PROC != State.FINISHED) Memory.setState(Context_PROC, State.FINISHED);} if (( State_ReturnPOIname == State.FAILED)) { if (State_PROC != State.FAILED) Memory.setState(Context_PROC, State.FAILED);} if (( State_ReturnPOIname == State.ABORTED)) { if (State_PROC != State.ABORTED) Memory.setState(Context_PROC, State.ABORTED);} if (( State_ReturnPOIname == State.SUSPENDED)) { if (State_PROC == State.RUNNING) Memory.setState(Context_PROC, State.SUSPENDED);} } if ((State_PROC == State.FINISHED) || (State_PROC == State.FAILED) || (State_PROC == State.ABORTED)) { Results.clear(); Results.put("City",Memory.Load(MakeAddress(Context_PROC,Box.Output,"City"))); Completed(Context_PROC, Results); } } }public void signalTasks(TID Context, int signal) throws MemoryException { SignalHandler sh = SignalHandler.getTaskSignalHandler(); sh.Signal(TASK(Context, "ReturnPOIname"), signal); } 
public void StartTaskReturnPOIname(TID Context) throws MemoryException {
int nc; boolean part_ok;
Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = new HashMap();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);
TID Context_TASK_ReturnPOIname = TASK(Context,"ReturnPOIname"); State State_ReturnPOIname = Memory.getState(Context_TASK_ReturnPOIname); Memory.Copy(MakeAddress(Context_PROC, Box.Input, "POI_JSon"), MakeAddress(Context_TASK_ReturnPOIname, Box.Input, "POI_JSon"));
InputParams.clear();InputParams.put("POI_JSon", Memory.Load(MakeAddress(Context_TASK_ReturnPOIname, Box.Input, "POI_JSon")));SystemInputParams.clear();TimeStamp(Context_TASK_ReturnPOIname,Box.ReadyTime); Exec.Start(Context_TASK_ReturnPOIname,InputParams,SystemInputParams);Memory.setState(Context_TASK_ReturnPOIname,State.WAITING); State_ReturnPOIname = State.WAITING;}

} //End of file