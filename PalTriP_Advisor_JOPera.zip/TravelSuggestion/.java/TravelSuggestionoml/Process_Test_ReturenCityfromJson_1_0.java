//JOpera Process Template Plugin
//OML2Java Compiler Version 1.12 $Revision: 6795 $
package TravelSuggestionoml;import org.jopera.kernel.*;import org.jopera.kernel.api.APIConsts;import java.util.*;import java.io.Serializable;public class Process_Test_ReturenCityfromJson_1_0 extends Template {public String getOMLPath() {  return "\\TravelSuggestion\\TravelSuggestionoml.oml";}

public String getOML() {  return "<PROCS><PROC OID=\"Process785\" NAME=\"Test_ReturenCityfromJson\" DESC=\"Automatically generated test process for ReturenCityfromJson\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter790\" NAME=\"POI_Json\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter791\" NAME=\"CityName\" DESC=\"\" TYPE=\"String\" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity792\" NAME=\"ReturenCityfromJson\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program671\" /></TASKS><DATAFLOW><BIND OID=\"Binding798\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter790\" DESTPID=\"InboxParameter672\" DESTTID=\"Activity792\" ACTION=\"0\" /><BIND OID=\"Binding801\" SRCTYP=\"0\" DESTTYP=\"3\" SRCPID=\"OutboxParameter673\" DESTPID=\"OutboxParameter791\" SRCTID=\"Activity792\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View786\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox794\" X=\"0.0\" Y=\"50.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity792\" REFTYPE=\"0\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View787\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow799\" SOURCE=\"RefBox797\" DESTINATION=\"RefBox795\" REF=\"Binding798\" REFTYPE=\"1\" ROUTE=\"2\" /><ARROW OID=\"Arrow802\" SOURCE=\"RefBox796\" DESTINATION=\"RefBox800\" REF=\"Binding801\" REFTYPE=\"1\" ROUTE=\"2\" /></ARROWS><BOXES><RBOX OID=\"RefBox788\" X=\"250.0\" Y=\"0.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process785\" REFTYPE=\"5\"><BOXES><RBOX OID=\"RefBox797\" X=\"250.0\" Y=\"50.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter790\" REFTYPE=\"3\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox789\" X=\"450.0\" Y=\"700.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Process785\" REFTYPE=\"6\"><BOXES><RBOX OID=\"RefBox800\" X=\"450.0\" Y=\"640.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter791\" REFTYPE=\"4\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox793\" X=\"350.0\" Y=\"350.0\" DX=\"0.0\" DY=\"0.0\" REF=\"Activity792\" REFTYPE=\"0\"><BOXES><RBOX OID=\"RefBox795\" X=\"325.0\" Y=\"300.0\" DX=\"0.0\" DY=\"0.0\" REF=\"InboxParameter672\" REFTYPE=\"3\"><BOXES /></RBOX><RBOX OID=\"RefBox796\" X=\"325.0\" Y=\"410.0\" DX=\"0.0\" DY=\"0.0\" REF=\"OutboxParameter673\" REFTYPE=\"4\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program671\" NAME=\"ReturenCityfromJson\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter672\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter673\" NAME=\"ZipCode\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getOMLInterface() {  return "<PROCINTER><INBOX><PARAM OID=\"InboxParameter790\" NAME=\"POI_Json\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter791\" NAME=\"CityName\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROCINTER>";}

public String getOML1() {  return "<PROCS><PROC OID=\"Process785\" NAME=\"Test_ReturenCityfromJson\" DESC=\"Automatically generated test process for ReturenCityfromJson\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\" PUBLISHED=\"true\" SUBPROC=\"false\" FLOWCONTROL=\"false\"><INBOX><PARAM OID=\"InboxParameter790\" NAME=\"POI_Json\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter791\" NAME=\"CityName\" DESC=\"\" TYPE=\"String\" /></OUTBOX><TASKS><ACTIVITY OID=\"Activity792\" NAME=\"ReturenCityfromJson\" DESC=\"\" ACT=\"\" COND=\"TRUE\" PRIORITY=\"0\" DEP=\"4\" SYNCH=\"0\" FAILH=\"0\" PROGRAMID=\"Program671\" /></TASKS><DATAFLOW><BIND OID=\"Binding798\" SRCTYP=\"3\" DESTTYP=\"0\" SRCPID=\"InboxParameter790\" DESTPID=\"InboxParameter672\" DESTTID=\"Activity792\" ACTION=\"0\" /><BIND OID=\"Binding801\" SRCTYP=\"0\" DESTTYP=\"3\" SRCPID=\"OutboxParameter673\" DESTPID=\"OutboxParameter791\" SRCTID=\"Activity792\" ACTION=\"0\" /></DATAFLOW><VIEWS><VIEW OID=\"View786\" NAME=\"ControlFlow\" DESC=\"\" VTYPE=\"0\"><ARROWS /><BOXES><RBOX OID=\"RefBox794\" DX=\"0.0\" DY=\"0.0\" X=\"0.0\" Y=\"-1.6666666\" REF=\"Activity792\" TYPE=\"0\" REFNAME=\"ReturenCityfromJson\"><BOXES /></RBOX></BOXES><GROUPS /></VIEW><VIEW OID=\"View787\" NAME=\"DataFlow\" DESC=\"\" VTYPE=\"1\"><ARROWS><ARROW OID=\"Arrow799\" REF=\"Binding798\" ROUTE=\"2\" ID1=\"RefBox797\" ID2=\"RefBox795\" TYPE=\"0\" /><ARROW OID=\"Arrow802\" REF=\"Binding801\" ROUTE=\"2\" ID1=\"RefBox796\" ID2=\"RefBox800\" TYPE=\"0\" /></ARROWS><BOXES><RBOX OID=\"RefBox788\" DX=\"0.0\" DY=\"0.0\" X=\"6.25\" Y=\"-0.0\" REF=\"Process785\" TYPE=\"5\" REFNAME=\"Test_ReturenCityfromJson\"><BOXES><RBOX OID=\"RefBox797\" DX=\"0.0\" DY=\"0.0\" X=\"6.25\" Y=\"-1.6666666\" REF=\"InboxParameter790\" TYPE=\"4\" REFNAME=\"POI_Json\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox789\" DX=\"0.0\" DY=\"0.0\" X=\"11.25\" Y=\"-23.333334\" REF=\"Process785\" TYPE=\"6\" REFNAME=\"Test_ReturenCityfromJson\"><BOXES><RBOX OID=\"RefBox800\" DX=\"0.0\" DY=\"0.0\" X=\"11.25\" Y=\"-21.333334\" REF=\"OutboxParameter791\" TYPE=\"3\" REFNAME=\"CityName\"><BOXES /></RBOX></BOXES></RBOX><RBOX OID=\"RefBox793\" DX=\"0.0\" DY=\"0.0\" X=\"8.75\" Y=\"-11.666667\" REF=\"Activity792\" TYPE=\"0\" REFNAME=\"ReturenCityfromJson\"><BOXES><RBOX OID=\"RefBox795\" DX=\"0.0\" DY=\"0.0\" X=\"8.125\" Y=\"-10.0\" REF=\"InboxParameter672\" TYPE=\"3\" REFNAME=\"POI_JSon\"><BOXES /></RBOX><RBOX OID=\"RefBox796\" DX=\"0.0\" DY=\"0.0\" X=\"8.125\" Y=\"-13.666667\" REF=\"OutboxParameter673\" TYPE=\"4\" REFNAME=\"ZipCode\"><BOXES /></RBOX></BOXES></RBOX></BOXES><GROUPS /></VIEW></VIEWS></PROC></PROCS><STUBS><PROGSTUB OID=\"Program671\" NAME=\"ReturenCityfromJson\" DESC=\"\" AUTHOR=\"\" VERSION=\"1.0\" VERSIONSTATUS=\"Stable\" CACHELIFETIME=\"0\" ABSTRACT=\"false\"><INBOX><PARAM OID=\"InboxParameter672\" NAME=\"POI_JSon\" DESC=\"\" TYPE=\"Json\" /></INBOX><OUTBOX><PARAM OID=\"OutboxParameter673\" NAME=\"ZipCode\" DESC=\"\" TYPE=\"String\" /></OUTBOX></PROGSTUB></STUBS>";}

public String getName() {  return "{TravelSuggestionoml}Test_ReturenCityfromJson[1.0]";}

public String getPackage() {  return "TravelSuggestionoml";}

public String getVersion() {  return "1.0";}

public String getAuthor() {  return "";}

public String getDescription() {  return "Automatically generated test process for ReturenCityfromJson";}

public String getCompileDate() {  return "2018-06-01 24:44:40.703";}

public Object getMetadata(String identifier) {
if ("ROUTER".equals(identifier)) {
return new Object[] {
new Object[] {new TID("{TravelSuggestionoml}Test_ReturenCityfromJson[1.0].0.-2"), "1=1", "TravelSuggestionoml/Test_ReturenCityfromJson/1.0"},
new Object[] {new TID("{TravelSuggestionoml}Test_ReturenCityfromJson[1.0].0.-2"), "boolean(/Envelope/Body/Test_ReturenCityfromJson)=true", "TravelSuggestionoml"}
};

}

else if ("WSDL".equals(identifier)) {
 return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<wsdl:definitions xmlns:wsdl=\"http://schemas.xmlsoap.org/wsdl/\" xmlns:apachesoap=\"http://xml.apache.org/xml-soap\" xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:typens=\"urn:/TravelSuggestionoml/Test_ReturenCityfromJson/1.0\" xmlns:wsdlsoap=\"http://schemas.xmlsoap.org/wsdl/soap/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" name=\"/TravelSuggestionoml/Test_ReturenCityfromJson/1.0Service\" targetNamespace=\"urn:/TravelSuggestionoml/Test_ReturenCityfromJson/1.0\">\n  <wsdl:message name=\"Test_ReturenCityfromJsonOutput\">\n    <wsdl:part name=\"CityName\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:message name=\"Test_ReturenCityfromJsonInput\">\n    <wsdl:part name=\"POI_Json\" type=\"xsd:string\" />\n  </wsdl:message>\n  <wsdl:portType name=\"/TravelSuggestionoml/Test_ReturenCityfromJson/1.0Port\">\n    <wsdl:operation name=\"Test_ReturenCityfromJsonRequest\">\n      <wsdl:input message=\"typens:Test_ReturenCityfromJsonInput\" />\n      <wsdl:output message=\"typens:Test_ReturenCityfromJsonOutput\" />\n    </wsdl:operation>\n  </wsdl:portType>\n  <wsdl:binding name=\"/TravelSuggestionoml/Test_ReturenCityfromJson/1.0Binding\" type=\"typens:/TravelSuggestionoml/Test_ReturenCityfromJson/1.0Port\">\n    <wsdlsoap:binding style=\"rpc\" transport=\"http://schemas.xmlsoap.org/soap/http\" />\n    <wsdl:operation name=\"Test_ReturenCityfromJsonRequest\">\n      <wsdlsoap:operation soapAction=\"urn:/TravelSuggestionoml/Test_ReturenCityfromJson/1.0Action\" />\n      <wsdl:input>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_ReturenCityfromJson/1.0\" use=\"encoded\" />\n      </wsdl:input>\n      <wsdl:output>\n        <wsdlsoap:body encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" namespace=\"urn:/TravelSuggestionoml/Test_ReturenCityfromJson/1.0\" use=\"encoded\" />\n      </wsdl:output>\n    </wsdl:operation>\n  </wsdl:binding>\n  <wsdl:service name=\"/TravelSuggestionoml/Test_ReturenCityfromJson/1.0Service\">\n    <wsdl:port binding=\"typens:/TravelSuggestionoml/Test_ReturenCityfromJson/1.0Binding\" name=\"/TravelSuggestionoml/Test_ReturenCityfromJson/1.0Port\">\n      <wsdlsoap:address location=\"http://@@LOCATION@@/services/TravelSuggestionoml/Test_ReturenCityfromJson/1.0\" />\n    </wsdl:port>\n  </wsdl:service>\n</wsdl:definitions>";
}

else if ("REST.PUBLISHED".equals(identifier)) {
return "published"; 
}

return null;
}
public void SetupImage(TID Context, Map Params) { SetupSystemBox(PROC(Context));TID Context_PROC = PROC(Context);SetupParam(Context_PROC,Box.Input,"POI_Json",Params.get("POI_Json")==null?"":Params.get("POI_Json"));SetupParam(Context_PROC,Box.Output,"CityName","");TimeStamp(Context_PROC,Box.ReadyTime);SetupReturenCityfromJson(Context);}public void SetupReturenCityfromJson(TID Context) {TID Context_TASK_ReturenCityfromJson = TASK(Context,"ReturenCityfromJson"); SetupSystemBox(Context_TASK_ReturenCityfromJson);SetupParam(Context_TASK_ReturenCityfromJson,Box.System,Box.Name,"ReturenCityfromJson");SetupParam(Context_TASK_ReturenCityfromJson,Box.System,Box.Type,Box.Activity);SetupParam(Context_TASK_ReturenCityfromJson,Box.System,Box.Prog,"{TravelSuggestionoml}ReturenCityfromJson[1.0]");SetupParam(Context_TASK_ReturenCityfromJson,Box.Input,"POI_JSon",null);SetupParam(Context_TASK_ReturenCityfromJson,Box.Output,"ZipCode",null);}public void Evaluate(TID Context) throws MemoryException {
if (log.isTraceEnabled()) {log.trace("Evaluate: " + Context + " " + Memory.getState(Context).toDebugString());}
boolean part_ok;int nc;Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = getResults();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);State State_PROC = Memory.getState(Context_PROC);
boolean changeCache = false;
TID Context_TASK_ReturenCityfromJson = TASK(Context,"ReturenCityfromJson"); State State_ReturenCityfromJson = Memory.getState(Context_TASK_ReturenCityfromJson);  if (State_PROC == State.INITIAL) {  TimeStamp(Context_PROC, Box.StartTime);  Exec.SetupTimeOut(Context_PROC);
// start task ReturenCityfromJson
if (State_ReturenCityfromJson == State.INITIAL) {Memory.Copy(MakeAddress(Context_PROC, Box.Input, "POI_Json"), MakeAddress(Context_TASK_ReturenCityfromJson, Box.Input, "POI_JSon"));
InputParams.clear();InputParams.put("POI_JSon", Memory.Load(MakeAddress(Context_TASK_ReturenCityfromJson, Box.Input, "POI_JSon")));SystemInputParams.clear();TimeStamp(Context_TASK_ReturenCityfromJson,Box.ReadyTime); Exec.Start(Context_TASK_ReturenCityfromJson,InputParams,SystemInputParams);Memory.setState(Context_TASK_ReturenCityfromJson,State.WAITING); State_ReturenCityfromJson = State.WAITING;}if (Box.True.equals(Memory.Load(MakeAddress(Context_PROC, Box.System, Box.SuspendAfterCreation)))) {
Memory.setState(Context_PROC, State.SUSPENDED);
} else { Memory.setState(Context_PROC, State.RUNNING);}
} else {   State State_Context = Memory.getState(Context);   if ((State_PROC == State.RUNNING) || (State_Context == State.FINISHING) || (State_Context == State.FAILED) || (State_Context == State.UNREACHABLE) || (State_Context == State.SKIPPED)) {

// TASK: ReturenCityfromJson

if (State_ReturenCityfromJson == State.OUTPUTTING) {
Memory.setState(Context_TASK_ReturenCityfromJson,State.RUNNING);
Exec.signalJob(Context_TASK_ReturenCityfromJson,APIConsts.SIGNAL_UNBLOCK);
}
if (State_ReturenCityfromJson == State.FINISHING) {
 Memory.Store(MakeAddress(Context_TASK_ReturenCityfromJson,Box.Output,"ZipCode"), (Serializable)Results.get("ZipCode")); Memory.Copy(MakeAddress(Context_TASK_ReturenCityfromJson, Box.Output, "ZipCode"), MakeAddress(Context_PROC, Box.Output, "CityName"));
if (State_PROC == State.SUSPENDED) {
Memory.setState(Context_TASK_ReturenCityfromJson,State.SUSPENDED_AFTER); State_ReturenCityfromJson = State.SUSPENDED_AFTER;} else {
MemoryAddress stream_address = MakeAddress(Context_TASK_ReturenCityfromJson, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_ReturenCityfromJson,State.OUTPUTTING); State_ReturenCityfromJson = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_ReturenCityfromJson,State.FINISHED); State_ReturenCityfromJson = State.FINISHED;}
} } else if (State_ReturenCityfromJson == State.RESUMING_AFTER) {
MemoryAddress stream_address = MakeAddress(Context_TASK_ReturenCityfromJson, Box.SystemOutput, Box.Stream); if (Memory.Load(stream_address) != null) {
Memory.setState(Context_TASK_ReturenCityfromJson,State.OUTPUTTING); State_ReturenCityfromJson = State.OUTPUTTING;  Memory.Store(stream_address,null);
 } else {
Memory.setState(Context_TASK_ReturenCityfromJson,State.FINISHED); State_ReturenCityfromJson = State.FINISHED;}
}
if (State_ReturenCityfromJson == State.RUN) {
TimeStamp(Context_TASK_ReturenCityfromJson,Box.StartTime);Memory.setState(Context_TASK_ReturenCityfromJson,State.RUNNING);
State_ReturenCityfromJson = State.RUNNING;
}
 if (( State_ReturenCityfromJson.isFinishedOrUnreachableOrSkipped() )) { if (State_PROC != State.FINISHED) Memory.setState(Context_PROC, State.FINISHED);} if (( State_ReturenCityfromJson == State.FAILED)) { if (State_PROC != State.FAILED) Memory.setState(Context_PROC, State.FAILED);} if (( State_ReturenCityfromJson == State.ABORTED)) { if (State_PROC != State.ABORTED) Memory.setState(Context_PROC, State.ABORTED);} if (( State_ReturenCityfromJson == State.SUSPENDED)) { if (State_PROC == State.RUNNING) Memory.setState(Context_PROC, State.SUSPENDED);} } if ((State_PROC == State.FINISHED) || (State_PROC == State.FAILED) || (State_PROC == State.ABORTED)) { Results.clear(); Results.put("CityName",Memory.Load(MakeAddress(Context_PROC,Box.Output,"CityName"))); Completed(Context_PROC, Results); } } }public void signalTasks(TID Context, int signal) throws MemoryException { SignalHandler sh = SignalHandler.getTaskSignalHandler(); sh.Signal(TASK(Context, "ReturenCityfromJson"), signal); } 
public void StartTaskReturenCityfromJson(TID Context) throws MemoryException {
int nc; boolean part_ok;
Map InputParams = new HashMap();Map SystemInputParams = new HashMap();Map Results = new HashMap();ITaskOutput taskOutput;
TID Context_PROC = PROC(Context);
TID Context_TASK_ReturenCityfromJson = TASK(Context,"ReturenCityfromJson"); State State_ReturenCityfromJson = Memory.getState(Context_TASK_ReturenCityfromJson); Memory.Copy(MakeAddress(Context_PROC, Box.Input, "POI_Json"), MakeAddress(Context_TASK_ReturenCityfromJson, Box.Input, "POI_JSon"));
InputParams.clear();InputParams.put("POI_JSon", Memory.Load(MakeAddress(Context_TASK_ReturenCityfromJson, Box.Input, "POI_JSon")));SystemInputParams.clear();TimeStamp(Context_TASK_ReturenCityfromJson,Box.ReadyTime); Exec.Start(Context_TASK_ReturenCityfromJson,InputParams,SystemInputParams);Memory.setState(Context_TASK_ReturenCityfromJson,State.WAITING); State_ReturenCityfromJson = State.WAITING;}

} //End of file